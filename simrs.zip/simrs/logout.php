<?php
session_start();
include '../../config/koneksi.php';
$timeout_duration = 120; // Timeout dalam detik

// Cek apakah user sudah login
if (isset($_SESSION['username']) && is_string($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Cek apakah waktu aktivitas terakhir tersimpan
    if (isset($_SESSION['last_activity'])) {
        $elapsed_time = time() - $_SESSION['last_activity'];

        // Jika sudah melewati batas waktu
        if ($elapsed_time > $timeout_duration) {
          if (isset($_SESSION['user_id'])) {
                $user_id = $_SESSION['user_id'];
                
             
            }

            session_unset();
           

            // Hapus cookie session (penting!)      
          
            header("Cache-Control: no-cache, no-store, must-revalidate");
            header("Pragma: no-cache");
            header("Expires: 0");
             session_destroy();
            header("Location: /index.php?logout=1"); // Redirect ke halaman login
            exit;
        }
    }

    // Perbarui waktu aktivitas terakhir
    $_SESSION['last_activity'] = time();


}


?>
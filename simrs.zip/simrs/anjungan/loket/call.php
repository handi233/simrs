<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

$conn = new mysqli("localhost", "root", "", "simrs");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$tanggal = date("Y-m-d");
$sql = "SELECT MAX(no_antrian) as terakhir FROM antrian_pasien WHERE tanggal = '$tanggal'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$no_antrian = $row['terakhir'] ?? 'Belum Ada';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Display Antrian</title>
    <meta http-equiv="refresh" content="5">
    <style>
        body {
            background-color: #87CEFA;
            color: #ff009dff;
            text-size:30px;
            text-align: center;
            font-family: 'Courier New', Courier, monospace;
            margin-top: 10px;
        }
        .title {
            font-size: 20px;
            margin-bottom: 20px;
            color: black;
            margin-top: 40px;
        }
        .antrian {
            font-size: 50px;
            font-weight: bold;
            color: #ff00d4c6;
            border: 10px solid #FFD700;
            display: inline-block;
            padding: 40px 80px;
            border-radius: 20px;
            margin-top: 20px;
        }
        .footer {
            font-size: 30px;
            color: #aaa;
            margin-top: 40px;
        }
        .marquee-box {
            width: 100%;
            height: 550px;
            overflow: hidden;
            position: relative;
            background: #fff3cd;
            border: 2px solid #ffa500;
            margin-top: 30px;
}

.marquee-content {
            position: absolute;
            width: 100%;
            animation: scrollDown 15s linear infinite;
}

@keyframes scrollDown {
            0% { top: -30%; }
            100% { top: 45%; }
}

    </style>
</head>
<body>
 <div class="marquee-box">
     <!-- <div class="marquee-content"> -->
    <div class="title">NOMOR ANTRIAN SAAT INI</div>
    <div class="antrian">A - <?= $no_antrian ?></div>



  

</body>
</html>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "simrs");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$tanggal = date("Y-m-d");
$no_antrian = "Belum Ada";
$nama_pasien = "-";
$playAudio = false;

// Jika form dipost dan ada nomor RM
if (isset($_POST['panggil_rm']) && !empty($_POST['no_rkm_medis'])) {
    $no_rm = $conn->real_escape_string($_POST['no_rkm_medis']);
    $sql = "SELECT no_antrian, nama FROM antrian_pasien WHERE no_rkm_medis = '$no_rm' AND tanggal = '$tanggal' LIMIT 1";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $no_antrian = $data['no_antrian'];
        $nama_pasien = $data['nama'];
        $playAudio = true;
    } else {
        echo "<script>alert('Data RM tidak ditemukan pada antrian hari ini');</script>";
    }
}
?>

<?php
$conn = new mysqli("localhost", "root", "", "simrs");
$tanggal = date("Y-m-d");

$sql = "SELECT * FROM pemanggilan_terakhir WHERE tanggal = '$tanggal' ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);
$data = $result->fetch_assoc();

$no_antrian = $data['no_antrian'] ?? 'Belum Ada';
$nama = $data['nama'] ?? '';
?>

<div class="marquee-box">
    <div class="marquee-content">
<div class="title">PASIEN SELANJUTNYA</div>

<body>
    <div class="antrian">A - <?= htmlspecialchars($no_antrian) ?>
    <div class="nama"><?= htmlspecialchars($nama) ?></div>
</body>
</html>
</div>

<?php
session_start();

// Koneksi database
$conn = new mysqli("localhost", "root", "", "simrs");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk ambil token dari berbagai sumber
function getToken() {
    if (isset($_GET['token']) && !empty($_GET['token'])) {
        return $_GET['token'];
    }

    if (isset($_SESSION['token']) && !empty($_SESSION['token'])) {
        return $_SESSION['token'];
    }

    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        if (preg_match('/Bearer\s(\S+)/', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
            return $matches[1];
        }
    }

    return null;
}

// Ambil token
$token = getToken();
if (!$token) {
    http_response_code(401);
    die(json_encode(["message" => "Akses ditolak: Token tidak tersedia."]));
}

// Validasi token dan waktu kadaluarsa (misal 30 menit)
$query = "
    SELECT users.* FROM tokens
    JOIN users ON tokens.user_id = users.user_id
    WHERE tokens.token = ?
    AND tokens.created_at >= NOW() - INTERVAL 30 MINUTE
    LIMIT 1
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    http_response_code(500);
    die(json_encode(["message" => "Prepare statement gagal: " . $conn->error]));
}

$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // Set session data user
    $_SESSION['username'] = $user['username'];
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['role'] = $user['role'];

    // Simpan token juga ke session supaya bisa dipakai di halaman lain tanpa kirim ulang token
    $_SESSION['token'] = $token;

    // Lanjutkan akses ke dasbor, halaman lain, dsb
    echo json_encode(["message" => "Token valid. Selamat datang, " . htmlspecialchars($user['username'])]);
} else {
    http_response_code(401);
    die(json_encode(["message" => "Token tidak valid atau telah kadaluarsa."]));
}
?>

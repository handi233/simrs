<?php
include '../../config/koneksi.php'; 

if (isset($_GET['users_id'])) {
    $id = intval($_GET['users_id']);

    // Query hapus
    $sql = "DELETE FROM users WHERE users_id = $id";
    if ($conn->query($sql) === TRUE) {
        header("Location: ../pengguna/index.php?pesan=sukses_hapus");
        exit;
    } else {
        echo "Gagal menghapus data: " . $conn->error;
    }
} else {
    echo "ID tidak ditemukan.";
}
?>

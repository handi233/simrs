<?php
// Koneksi ke database
include '../../config/koneksi.php';

if (isset($_GET['kode'])){
    mysqli_query($conn,"delete from users where user_id='$_GET[kode]'");

    echo"data sudah terhapus!!";
    echo"<meta http-equiv=refresh content=2;URL='../../modul/pengguna/index.php'>";
}

?>
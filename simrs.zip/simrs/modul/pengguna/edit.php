<?php
include '../../config/koneksi.php';
include '../../logout.php';




if (!isset($_SESSION['username'])) {
      header("Location: /simrs/index.php?logout=1");
    exit;
    $username = $_SESSION['username'];
}
?>
<?php
// Koneksi database
include '../../config/koneksi.php';

// User ID dari session atau dari input (pastikan sudah ada)
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;


$permissions = [];
$selectedPermissions = [];

// Ambil semua permission dari tabel permissions
$result = $conn->query("SELECT * FROM permissions");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $permissions[] = $row;
    }
} else {
    die("Query permissions gagal: " . $conn->error);
}

// Ambil permission yang sudah dimiliki user
$selectedPermissions = [];
if ($user_id) {
    $res = $conn->query("SELECT permission_id FROM user_permissions WHERE user_id = $user_id");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $selectedPermissions[] = $row['permission_id'];
        }
        
    }
}

?>

<style>
.table-scroll {
    margin-left: 10px; 
   table-layout: auto;
    width: 70%;

}
.table-scroll table {
    min-width: 70px; /* atur sesuai kebutuhan */
    border-collapse: collapse;
}
.table-scroll th, .table-scroll td {
    padding: 1px;
    border: 0px solid #ccc;
    white-space: nowrap; /* supaya isi kolom tidak patah */
}

.footer{
position: fixed;
margin-bottom: 12px;
   top: 552px;
    bottom: none;
    left: 0;
    width: 100%;
  background-color: green;
    border-top: 0 solid #ccc;
    padding: 0;
}
.simpan{
  width: 100px;
  height: 70px;
  margin-left: 10px;
}
.dropdown-checkbox {
  margin-top: 30px;
  margin-left: 30px;
  position: relative;
  display: inline-block;
  width: 250px;
}

.dropdown-checkbox .dropdown-button {
  
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  background-color: white;
  cursor: pointer;
}

.dropdown-checkbox .dropdown-content {
    margin-left: 30px;
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  width: 100%;
  max-height: 210px;
  overflow-y: auto;
  box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-checkbox .dropdown-content label {
  margin-left: 30px;
  display: block;
  padding: 5px 10px;
  cursor: pointer;
}

.dropdown-checkbox .dropdown-content label:hover {
    margin-left: 30px;
  background-color: #f1f1f1;
}
</style>
   <?php
// Pastikan $user_id sudah didapat dari $_GET dan di-sanitize
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    die("User ID tidak valid.");
}

// Query username user target
$queryUser = $conn->query("SELECT username FROM users WHERE user_id = $user_id");

if (!$queryUser) {
    die("Query gagal: " . $conn->error);
}

$targetUser = $queryUser->fetch_assoc();

if (!$targetUser) {
    die("User tidak ditemukan.");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Hak Akses <?= htmlspecialchars($targetUser['username']) ?></title>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<meta name="robots" content="noindex, follow">
 <link rel="stylesheet" 
          href=
"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<style> 
     .navbar-dark.bg-succes {
            background-color: lightgreen;
           
        }
        .navbar{
            height: 50px;
             padding-top: 10px;
      padding-bottom: 10px;
    }
    .dropdown {
  position: relative;
  display: inline-block;
}
.transparent-button {
  background-color: transparent;
  color: inherit;       /* ikut warna teks induk */
  border: none;         /* hilangkan border */
  padding: 10px 20px;
  cursor: pointer;
}
.dua {
  position: fixed;
  top: 155px;
  left: 200px;

}
.tiga {
  position: fixed;
  top: 155px;
  left: 300px;

}
.empat {
  position: fixed;
  top: 157px;
  left: 380px;

}
.lima {
  position: fixed;
  top: 157px;
  left: 460px;

}
.enam {
  position: fixed;
  top: 157px;
  left: 550px;


  }
.tujuh {
  position: fixed;
  top: 157px;
  left: 720px;

}
.selamatdatang {
  position: absolute;
  top: 15px;
  right: 130px;
  }
 
.daftarpasien {
  position: absolute;
  margin-top: 15px;
  left: 110px;

}
.exit {
  position: absolute;
  top: 10px;
  right: 10px;

}
.textdaftarpasien {
  position:absolute;
  top: 5px;
  color: white;
  margin-left: 90px;
}
.home {
  position: absolute;
   margin-top:15px;
  left: 15px;
  }
  .hometext {
  position: absolute;
  margin-top: 35px;
  color: white;
  }
  .h1title {
  position:absolute;
  top: 70px;
  left: 20px;
  background-color:transparent;
  text-decoration: none;
  background: 0.2s;
  color: green;
  box-sizing: border-box;
  }
   

  body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.id{
  margin-right: 50px;
}
/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

.modal{
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  right: 30;
  top: 0;
  width: 100%; /* Full width */
  height: 120%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}
.modal-content {
  background-color: #fefefe;
  margin: 7% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
  height: 50%;
 }

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 100px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 50%;
  }
}
.btnform {
     margin-left: 30px;
     margin-top: 80px;
  }
  .inputform {
    padding-top:15px;
    font-size:13px;
    width: 300px;
    }
.save{
  background-color: #008CBA;
  margin-top: 5px;
  width: 100px;
  height: 70px;
}
     
  .home {
  position: absolute;
   margin-top: 0px;
  left: 20px;
  }
  .hometext {
  position: absolute;
  top: -20px;
  color: white;
  }
  .table{
    position: absolute;
    margin-top: 200px;
    margin-left: 25%;
    margin-right: 20px;
    margin-bottom: auto;
    width: 50%;
.form {
    top:80%;
}
}


 
</style>
<script>
   function closeFunction() {
  }

  </script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
  }

</script>
</style>
<nav>
    <nav class="navbar navbar-dark bg-success">
 <div class="selamatdatang">
       <p style="color: white;">
        <?php
    if (isset($_SESSION['username'])) {
    echo 'Selamat Datang, ' . htmlspecialchars($_SESSION['username']);
      }
      else{
        
        
      }
       ?>
   </p>
</div>
      <div class="exit">
    <a href="/simrs/index.php?logout=1"><img src="/simrs/asset/images/icon/exit.png" height="30"></a>
      </div>
           <div class="home">
           </div>
             <div class="hometext">
   <p><a href="../../modul/dasbor/"><img src="/simrs/asset/img/home.png" height="25"></a>  Home</p>
      </div>
        <div class="daftarpasien">
        </div>
           <div class="textdaftarpasien">
   <p><a href="../../modul/pasien/index.php"><img src="/simrs/asset/images/listpasien.png" height="50"></a>Pasien</p>
      </div>
    </nav>
 
</div>
</nav>
</head>
<body>
  <div>

<h1 class="h1title">Hak Akses untuk <?= htmlspecialchars($targetUser['username']) ?></h1>

</div>
<?php
// koneksi ke database
include'../../config/koneksi.php';

// ambil data permission
$permissions = [];
$result = $conn->query("SELECT * FROM permissions");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $permissions[] = $row;
    }
} else {
    die("Query failed: " . $conn->error);
}
?>

<?php


$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    die(" User ID tidak valid.");
}
?>

   <form class="modal-content animate" action="save_permissions.php" method="POST">
    <input type="hidden" name="user_id" value="<?= $user_id ?>">
    <div class="container">
      <div class="dropdown-checkbox">
  <div class="dropdown-button" onclick="toggleDropdown()">Pilih Hak Akses Modul</div>
  <div class="dropdown-content" id="dropdownPermissions">
     <?php foreach($permissions as $perm): ?>
    <div class="form-check">
      <label class="form-check-label" for="perm_<?= $perm['id'] ?>">
      <input 
             class="form-check-input" 
             type="checkbox" 
             name="permissions[]" 
             value="<?= $perm['id'] ?>" 
             id="perm_<?= $perm['id'] ?>"
          <?= in_array((string)$perm['id'], $selectedPermissions) ? 'checked' : '' ?>
>
 <?= htmlspecialchars($perm['permission_name']) ?>
     </label>
     </div>
  <?php endforeach; ?>
   </div>
<button class="simpan" type="submit" name="simpan">
  <img src="../../asset/img/save.png" width="15">Simpan
</button>
 </form>
 
 <?php if (isset($_GET['status']) && $_GET['status'] === 'sukses'): ?>
<p style="color:green;">Hak akses berhasil disimpan!</p>
<?php endif; ?>

 <script>
function toggleDropdown() {
  const dropdown = document.getElementById("dropdownPermissions");
  dropdown.style.display = (dropdown.style.display === "block") ? "none" : "block";
}

// Menutup dropdown jika klik di luar
window.onclick = function(event) {
const modal = document.getElementById('id01');
  if (modal && event.target === modal) {
    modal.style.display = "none";
  }

  if (!event.target.matches('.dropdown-button')) {
    const dropdowns = document.getElementsByClassName("dropdown-content");
    for (let i = 0; i < dropdowns.length; i++) {
      if (dropdowns[i].style.display === "block") {
        dropdowns[i].style.display = "none";
      }
    }
  }
}
</script>
<footer style="margin-top: 40px;">
<div class="footer">
  <div class="tanggal">
<footer style="text-align: left ; margin-top: 7px;  color: white;">
  <span id="tanggal"></span>

  <script>
    const hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    const bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

    const now = new Date();
    const hariIni = hari[now.getDay()];
    const tanggal = now.getDate();
    const bulanIni = bulan[now.getMonth()];
    const tahun = now.getFullYear();

    document.getElementById('tanggal').innerText = ` ${hariIni}, ${tanggal} ${bulanIni} ${tahun}`;
  </script>
</footer>
</div>
</div>
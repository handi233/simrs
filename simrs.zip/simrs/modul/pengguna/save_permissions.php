<?php
session_start();
include '../../config/koneksi.php';
include '../../modul/pengguna/auth_check.php';  

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['simpan'])) {
    $userId = intval($_POST['user_id'] ?? 0);
    $selectedPermissions = $_POST['permissions'] ?? [];

    if (!$userId) {
        die("User ID tidak ditemukan");
    }
     // Proteksi admin agar disable check box
    if ($userId === 1) {
        die("hak akses operator tidak bisa diedit");
    }
    // Hapus permission lama user
    $conn->query("DELETE FROM user_permissions WHERE user_id = $userId");

    // Insert permission baru
    if (count($selectedPermissions) > 0) {
        $values = [];
        foreach ($selectedPermissions as $permId) {
            $permId = intval($permId);
            if ($permId > 0) {
                $values[] = "($userId, $permId)";
            }
        }

        if (count($values) > 0) {
            $sql = "INSERT INTO user_permissions (user_id, permission_id) VALUES " . implode(", ", $values);
            if (!$conn->query($sql)) {
                die("Gagal simpan hak akses: " . $conn->error);
            }
        }
    }

    // Redirect kembali ke halaman form dengan status sukses
    header("Location: edit.php?id=$userId&status=sukses");
    exit;
} else {
    die("Metode request salah.");
}
?>
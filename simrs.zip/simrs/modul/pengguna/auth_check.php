<?php
function hasPermission($conn, $userId, $permissionId) {
    $stmt = $conn->prepare("SELECT permission_id FROM user_permissions WHERE user_id = ? AND permission_id = ?");
    $stmt->bind_param("ii", $userId, $permissionId);
    $stmt->execute();
    $stmt->store_result();
    $has = $stmt->num_rows > 0;
    $stmt->close();
    return $has;
}
?>
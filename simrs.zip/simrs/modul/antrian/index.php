<?php
include '../../config/koneksi.php';
include '../../logout.php';

header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0"); 


if (!isset($_SESSION['username'])) {
      header("Location: /simrs/index.php?logout=1");
    exit;
    $username = $_SESSION['username'];
}


include '../../config/koneksi.php';  
include '../../modul/pengguna/auth_check.php';  // file ambil file user_id db


$userId = $_SESSION['user_id'] ?? 0;  

if (!$userId) {
    header("Location: /simrs");
    exit;
}


$permissionId = 14;

if (!hasPermission($conn, $userId, $permissionId)) {
    die("Akses ditolak: Anda tidak memiliki hak akses untuk melihat halaman ini.");
}

?>

<?php
include '../../config/koneksi.php';
$query = "SELECT nama_instansi FROM settings LIMIT 1";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

$nama_instansi = $data['nama_instansi'];
?>

<style>
.table-scroll {
   overflow-x: auto;
     white-space: nowrap;
}
.table-scroll table {
   width: 100%;
   table-layout: auto;
}
.table-scroll th, .table-scroll td {
    padding: 1px;
    border: 0px solid #ccc;
    white-space: nowrap; /* supaya isi kolom tidak patah */
}

.footer{
position: fixed;
margin-bottom: 20px;
   top: 552px;
    bottom: none;
    left: 0;
   width: 100%;
    background-color: green;
    border-top: 0 solid #ccc;
    padding: 0;
    height: 50%;
}
.simpan{
  width: 100px;
  height: 70px;
}
</style>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="referrer" content="no-referrer">
	<title>Antrian <?php echo $nama_instansi?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<meta name="robots" content="noindex, follow">
 <link rel="stylesheet" href= "https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<style> 
     .navbar-dark bg-succes {
            background-color: lightgreen;
           
        }
        .navbar{
 position: fixed;
    top: 0; /* Tambahkan ini agar navbar menempel di atas */
    left: 0;
    right: 0;
    height: 50px;
    margin-top: 0; /* Pastikan margin-top tidak mendorong navbar ke bawah */
    display: flex;
    align-items: center;
    padding: 0 20px;
    z-index: 1000; 
            
    }
 

.transparent-button {
  background-color: transparent;
  color: inherit;       /* ikut warna teks induk */
  border: none;         /* hilangkan border */
  padding: 10px 20px;
  cursor: pointer;
}
.dua {
  position: fixed;
  top: 155px;
  left: 200px;

}
.tiga {
  position: fixed;
  top: 155px;
  left: 300px;

}
.empat {
  position: fixed;
  top: 157px;
  left: 380px;

}
.lima {
  position: fixed;
  top: 157px;
  left: 460px;

}
.enam {
  position: fixed;
  top: 157px;
  left: 550px;


  }
.tujuh {
  position: fixed;
  top: 157px;
  left: 720px;

}
.selamatdatang {
  position: absolute;
  top:14px;
  right: 130px;
  }
 


.exit {
  position: absolute;
  top: 10px;
  right: 10px;

}
.home {
  position: absolute;
  }
  .hometext {
  position: absolute;
  top: 15px;
  color: white;
  margin-left: 20px;
  }
  
   





</style>


<nav>
    <nav class="navbar navbar-dark bg-success">
   <div class="selamatdatang">
       <p style="color: white;">
        <?php
    if (isset($_SESSION['username'])) {
    echo 'Selamat Datang, ' . htmlspecialchars($_SESSION['username']);
      }
      else{
        
        
      }
       ?>
   </p>
</div>
</div>
      <div class="exit">
    <a href="/simrs/index.php?logout=1"><img src="/simrs/asset/images/icon/exit.png" height="30"></a>
      </div>
           <div class="home">
           </div>
             <div class="hometext">
   <p style="text-align:center;"><a href="../../modul/dasbor/"><img src="/simrs/asset/img/home.png" height="25"></a>Home</p>
      </div>
       
    </nav>
 
</head>
<body>
  
<!DOCTYPE html>

<head>
    <meta charset="UTF-8" />
    <title>Antrian - Pemanggil No RM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="refresh" content="10" /> <!-- Refresh otomatis 10 detik -->

    <!-- Bootstrap CSS (gunakan versi CDN agar gampang) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />

    <style>
        body {
            background-color: #87CEFA;
            color: #394339ff;
            font-family: 'Courier New', Courier, monospace;
            margin-top: 0px;
            text-align: center;
        }
        .title {
            font-size: 40px;
            margin-bottom: 5px;
            color: green;
        }
        .antrian {
            font-size: 100px;
            font-weight: bold;
            color: #FFD700;
            border: 10px solid #FFD700;
            display: inline-block;
            padding: 30px 60px;
            border-radius: 20px;
            margin-top: 20px;
            background-color: rgba(0,0,0,0.3);
        }
        .nama {
            font-size: 30px;
            color: white;
            margin-top: 10px;
        }
        .form-container {
            margin-top: 40px;
        }
        input[type="text"] {
            font-size: 24px;
            padding: 10px;
            width: 300px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button.panggil-button {
            font-size: 24px;
            padding: 10px 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 10px;
            margin-left: 10px;
            cursor: pointer;
            width: 119px;
            transition: background-color 0.3s;
        }
        button.panggil-button:hover {
            background-color: #218838;
        }
        
    </style>
</head>
<body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

$conn = new mysqli("localhost", "root", "", "simrs");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$tanggal = date("Y-m-d");
$no_antrian = "Belum Ada";
$nama_pasien = "-";
$playAudio = false;

if (isset($_POST['panggil_rm']) && !empty($_POST['no_rkm_medis'])) {
    $no_rm = $conn->real_escape_string($_POST['no_rkm_medis']);
    $sql = "SELECT no_antrian, nama FROM antrian_pasien WHERE no_rkm_medis = '$no_rm' AND tanggal = '$tanggal' LIMIT 1";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $no_antrian = $data['no_antrian'];
        $nama_pasien = $data['nama'];
        $playAudio = true;

        // Simpan ke tabel pemanggilan_terakhir
        $conn->query("INSERT INTO pemanggilan_terakhir (tanggal, no_antrian, nama) 
                      VALUES ('$tanggal', '$no_antrian', '$nama_pasien')");
    } else {
        echo "<script>alert('Data RM tidak ditemukan pada antrian hari ini');</script>";
    }
}
?>
<div class="title">PEMANGGIL ANTRIAN <?php echo $nama_instansi ?></div>

 <?php
include'../../config/koneksi.php';
$query = "SELECT no_rkm_medis,nama,no_antrian,tanggal,waktu FROM antrian_pasien WHERE DATE(tanggal) = CURDATE()";
$result = mysqli_query($conn, $query);
?>
<div class="container mt-4 table-scroll">
<table id="example" class="display nowrap"style="width:100%">
    <thead>
            <tr>
                <th>NO.RM</th>
                <th>Nama</th>
                <th>No Antrian</th>
                <th>Tanggal Kunjungan</th>
                 <th>Waktu</th>
                   <th>Aksi</th>
                   
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                    
                          <td><?= htmlspecialchars($row["no_rkm_medis"]) ?></td>
                          <td><?= htmlspecialchars($row["nama"]) ?></td>
                        <td><?= htmlspecialchars($row["no_antrian"]) ?></td>
                           <td><?= htmlspecialchars($row["tanggal"]) ?></td>
                             <td><?= htmlspecialchars($row["waktu"]) ?></td>
                         <td><button type="button"
                                class="btn btn-primary btn-sm call-btn"
                                no_antrian="<?= htmlspecialchars($row['no_antrian']) ?>"
                                nama="<?= htmlspecialchars($row['nama']) ?>">
                            🔊 Call
                        </button></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">Data tidak ditemukan.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    
   <script>
document.addEventListener('DOMContentLoaded', () => {
  let voices = [];

  function loadVoices() {
    return new Promise((resolve) => {
      voices = speechSynthesis.getVoices();
      if (voices.length !== 0) {
        resolve(voices);
      } else {
        speechSynthesis.onvoiceschanged = () => {
          voices = speechSynthesis.getVoices();
          resolve(voices);
        };
      }
    });
  }

  loadVoices(); // Inisialisasi suara

  document.getElementById('example').addEventListener('click', async (e) => {
    if (e.target && e.target.classList.contains('call-btn')) {
      const button = e.target;
      const no_antrian = button.getAttribute('no_antrian');
      const nama = button.getAttribute('nama');
      const message = `Nomor antrian ${no_antrian}, atas nama ${nama}, silakan menuju ke loket pendaftaran`;

      const utterance = new SpeechSynthesisUtterance(message);
      utterance.lang = 'id-ID';
      utterance.rate = 0.9;

      const allVoices = await loadVoices();
      const indoVoice = allVoices.find(v => v.lang === 'id-ID');

      if (indoVoice) {
        utterance.voice = indoVoice;
        console.log("Suara Indonesia digunakan:", indoVoice.name);
      } else {
        console.warn("Suara Indonesia tidak tersedia. Gunakan default.");
      }

      // Batalkan suara sebelumnya dan putar
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
    }
  });
});
</script>


    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap4.js"></script>
<script>
  new DataTable('#example', {
    scrollX: true
});




<?php
$con = mysqli_connect('localhost','root','','simrs');
$query = "SELECT nama_instansi FROM settings LIMIT 1";
$result = mysqli_query($con, $query);
$data = mysqli_fetch_assoc($result);

$nama_instansi = $data['nama_instansi'];
?>
<?php
session_start();

// Cek apakah user sudah login (cek session user_id)
if (!isset($_SESSION['user_id'])) {
}

// Jika sudah login, lanjutkan tampilkan halaman dashboard
?>
<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// Cek apakah pengguna sudah login


if (empty($_SESSION['username'])) {
    $_SESSION['username'];
}

?>
<style>
.table-scroll {
    margin-left: 10px; 
   table-layout: absolute;
    width: 70%;

}
.table-scroll table {
    min-width: 70px; /* atur sesuai kebutuhan */
    border-collapse: collapse;
}
.table-scroll th, .table-scroll td {
    padding: 1px;
    border: 0px solid #ccc;
    white-space: nowrap; /* supaya isi kolom tidak patah */
}

.footer{
position: fixed;
margin-bottom: 20px;
   top: 552px;
    bottom: none;
    left: 0;
   width: 100%;
    background-color: green;
    border-top: 0 solid #ccc;
    padding: 0;
    height: 50%;
}
.simpan{
  width: 100px;
  height: 70px;
}
</style>




<!DOCTYPE html>
<html lang="en">
<head>
	<title>Antrian <?php echo $nama_instansi?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<meta name="robots" content="noindex, follow">
 <link rel="stylesheet" 
          href=
"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<style> 
     .navbar-dark bg-succes {
            background-color: lightgreen;
           
        }
        .navbar{
 position: fixed;
    top: 0; /* Tambahkan ini agar navbar menempel di atas */
    left: 0;
    right: 0;
    height: 50px;
    margin-top: 0; /* Pastikan margin-top tidak mendorong navbar ke bawah */
    display: flex;
    align-items: center;
    padding: 0 20px;
    z-index: 1000; 
            
    }
 

.transparent-button {
  background-color: transparent;
  color: inherit;       /* ikut warna teks induk */
  border: none;         /* hilangkan border */
  padding: 10px 20px;
  cursor: pointer;
}
.dua {
  position: fixed;
  top: 155px;
  left: 200px;

}
.tiga {
  position: fixed;
  top: 155px;
  left: 300px;

}
.empat {
  position: fixed;
  top: 157px;
  left: 380px;

}
.lima {
  position: fixed;
  top: 157px;
  left: 460px;

}
.enam {
  position: fixed;
  top: 157px;
  left: 550px;


  }
.tujuh {
  position: fixed;
  top: 157px;
  left: 720px;

}
.selamatdatang {
  position: absolute;
  top:14px;
  right: 130px;
  }
 


.exit {
  position: absolute;
  top: 10px;
  right: 10px;

}
.home {
  position: absolute;
  }
  .hometext {
  position: absolute;
  top: 15px;
  color: white;
  margin-left: 20px;
  }
  
   





</style>


<nav>
    <nav class="navbar navbar-dark bg-success">
      <div class="selamatdatang">
       <p style="color: white;">
        <?php
    echo "Selamat Datang, " . htmlspecialchars($_SESSION['username']);
       ?>
   </p>
</div>
      <div class="exit">
    <a href="http://localhost/simrs"><img src="/simrs/asset/images/icon/exit.png" height="30"></a>
      </div>
           <div class="home">
           </div>
             <div class="hometext">
   <p style="text-align:;"><a href="../../modul/dasbor/"><img src="/simrs/asset/img/home.png" height="25"></a>Home</p>
      </div>
       
    </nav>
 
</head>
<body>
<!DOCTYPE html>

<head>
    <meta charset="UTF-8" />
    <title>Antrian - Pemanggil No RM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="refresh" content="10" /> <!-- Refresh otomatis 10 detik -->

    <!-- Bootstrap CSS (gunakan versi CDN agar gampang) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />

    <style>
        body {
            background-color: #87CEFA;
            color: #00FF00;
            font-family: 'Courier New', Courier, monospace;
            margin-top: 0px;
            text-align: center;
        }
        .title {
            font-size: 40px;
            margin-bottom: 5px;
            color: green;
        }
        .antrian {
            font-size: 100px;
            font-weight: bold;
            color: #FFD700;
            border: 10px solid #FFD700;
            display: inline-block;
            padding: 30px 60px;
            border-radius: 20px;
            margin-top: 20px;
            background-color: rgba(0,0,0,0.3);
        }
        .nama {
            font-size: 30px;
            color: white;
            margin-top: 10px;
        }
        .form-container {
            margin-top: 40px;
        }
        input[type="text"] {
            font-size: 24px;
            padding: 10px;
            width: 300px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button.panggil-button {
            font-size: 24px;
            padding: 10px 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 10px;
            margin-left: 10px;
            cursor: pointer;
            width: 119px;
            transition: background-color 0.3s;
        }
        button.panggil-button:hover {
            background-color: #218838;
        }
        
    </style>
</head>
<body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Jakarta');

$conn = new mysqli("localhost", "root", "", "simrs");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$tanggal = date("Y-m-d");
$no_antrian = "Belum Ada";
$nama_pasien = "-";
$playAudio = false;

if (isset($_POST['panggil_rm']) && !empty($_POST['no_rkm_medis'])) {
    $no_rm = $conn->real_escape_string($_POST['no_rkm_medis']);
    $sql = "SELECT no_antrian, nama FROM antrian_pasien WHERE no_rkm_medis = '$no_rm' AND tanggal = '$tanggal' LIMIT 1";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $no_antrian = $data['no_antrian'];
        $nama_pasien = $data['nama'];
        $playAudio = true;

        // Simpan ke tabel pemanggilan_terakhir
        $conn->query("INSERT INTO pemanggilan_terakhir (tanggal, no_antrian, nama) 
                      VALUES ('$tanggal', '$no_antrian', '$nama_pasien')");
    } else {
        echo "<script>alert('Data RM tidak ditemukan pada antrian hari ini');</script>";
    }
}
?>

<div class="title">PEMANGGIL ANTRIAN <?php echo $nama_instansi ?></div>

<div class="antrian">A - <?= htmlspecialchars($no_antrian) ?></div>
<div class="nama"><?= htmlspecialchars($nama_pasien) ?></div>

<div class="form-container">
    <form method="post" onsubmit="return playSound();">
        <input type="text" name="no_rkm_medis" placeholder="Masukkan No RM" required autocomplete="off" />
        <button type="submit" name="panggil_rm" class="panggil-button">🔊 Panggil Antrian</button>
    </form>
</div>

<audio id="audioPanggilan" src="../simrs/assets/sounds/panggilan.mp3" preload="auto"></audio>

<?php if ($playAudio): ?>
<script>
window.onload = function() {
    var audio = document.getElementById("audioPanggilan");
    if (audio) {
        audio.play().catch(function(err) {
            alert("Gagal memutar suara: " + err.message);
        });
    }
};
</script>
<?php endif; ?>





<?php
session_start();

if (!isset($_SESSION['antrian'])) {
    $_SESSION['antrian'] = [];
}

$nomor_baru = count($_SESSION['antrian']) + 1;
$_SESSION['antrian'][] = $nomor_baru;

header("Location: index.php");
exit();

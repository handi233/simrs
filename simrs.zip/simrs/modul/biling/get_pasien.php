<?php
header('Content-Type: application/json');
if (isset($_POST['no_rkm_medis'])) {
    $no_rkm_medis = $_POST['no_rkm_medis'];

    // Koneksi ke database
    $conn = new mysqli("localhost", "root", "", "simrs");

    if ($conn->connect_error) {
        echo json_encode(['error' => 'Koneksi gagal']);
        exit;
    }

    $stmt = $conn->prepare("SELECT nama FROM pasien WHERE no_rkm_medis = ?");
    $stmt->bind_param("s", $no_rkm_medis);
    $stmt->execute();
    $stmt->bind_result($nama);

    if ($stmt->fetch()) {
        echo json_encode(['nama' => $nama]);
    } else {
        echo json_encode(['nama' => null]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(['error' => 'No RM tidak dikirim']);
}
?>
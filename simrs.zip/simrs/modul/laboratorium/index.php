<?php
include '../../config/koneksi.php';
include '../../logout.php';

header("Cache-Control: no-cache, no-store, must-revalidate"); 
header("Pragma: no-cache"); 
header("Expires: 0"); 


if (!isset($_SESSION['username'])) {
      header("Location: /simrs/index.php?logout=1");
    exit;
    $username = $_SESSION['username'];
}

include '../../config/koneksi.php';  
include '../../modul/pengguna/auth_check.php'; 

$userId = $_SESSION['user_id'] ?? 0;  

if (!$userId) {
    header("Location: /simrs");
    exit;
}


$permissionId = 7;

if (!hasPermission($conn, $userId, $permissionId)) {
    die("Akses ditolak: Anda tidak memiliki hak akses untuk melihat halaman ini.");
}

?>
<?php
// Koneksi ke database
include '../../config/koneksi.php';

if (isset($_GET['id'])){
    mysqli_query($conn,"delete from laborat where id='$_GET[id]'");

    echo '<div class="alert-danger">Data sudah terhapus!!</div>';
    echo"<meta http-equiv=refresh content=2;URL='../../modul/laboratorium/index.php'>";
}

?>

<style>
    label {
    font-size: 12px; 
  
}

select {
    font-size: 16px; 
    padding: 10px; 
    height: 40px; 
    width: 100%; 
}
.table-scroll {
    margin-left: 10px; 
   table-layout: absolute;
    width: 70%;

}
.table-scroll table {
    min-width: 70px; /* atur sesuai kebutuhan */
    border-collapse: collapse;
}
.table-scroll th, .table-scroll td {
    padding: 1px;
    border: 0px solid #ccc;
    white-space: nowrap; /* supaya isi kolom tidak patah */
}

.footer{
position: fixed;
margin-bottom: 12px;
   top: 552px;
    bottom: none;
    left: 0;
    width: 100%;
  background-color: green;
    border-top: 0 solid #ccc;
    padding: 0;
}
.simpan{
  width: 75px;
  height: 70px;
  margin-left: 5px;
  margin-top: 5px;
}
</style>


<?php
include '../../config/koneksi.php';

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (isset($_POST['simpan'])) {
    $no_rkm_medis= $_POST['no_rkm_medis'];
     $nama= $_POST['nama'];
    $tgl_periksa   = $_POST['tgl_periksa'];
    $jam_periksa    = $_POST['jam_periksa'];
    $nama_dokter    = $_POST['nama_dokter'];
     $nama_pj    = $_POST['nama_pj'];
    $hasil_lab    = $_POST['hasil_lab'];
  


  

    $stmt = $conn->prepare("INSERT INTO laborat (`no_rkm_medis`,`nama`,`tgl_periksa`,`jam_periksa`,`nama_dokter`,`nama_pj`,`hasil_lab`) VALUES (?,?,?,?,?,?,?)");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssssss", $no_rkm_medis, $nama, $tgl_periksa,$jam_periksa,$nama_dokter,$nama_pj,$hasil_lab);

    if ($stmt->execute()) {
        echo "Data berhasil ditambahkan!";
    } else {
        echo "Gagal menambahkan data: " . $stmt->error;
    }
  
    $stmt->close();
    $conn->close();
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>LABORATORIUM</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<meta name="robots" content="noindex, follow">
 <link rel="stylesheet" 
          href=
"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/2.3.2/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<style> 
     .navbar-dark bg-succes {
            background-color: lightgreen;
           
        }
        .navbar{
            height: 50px;
             padding-top: 10px;
      padding-bottom: 10px;
    }
    .dropdown {
  position: relative;
  display: inline-block;
}
.transparent-button {
  background-color: transparent;
  color: inherit;       /* ikut warna teks induk */
  border: none;         /* hilangkan border */
  padding: 10px 20px;
  cursor: pointer;
}
.dua {
  position: fixed;
  top: 155px;
  left: 200px;

}
.tiga {
  position: fixed;
  top: 155px;
  left: 300px;

}
.empat {
  position: fixed;
  top: 157px;
  left: 380px;

}
.lima {
  position: fixed;
  top: 157px;
  left: 460px;

}
.enam {
  position: fixed;
  top: 157px;
  left: 550px;


  }
.tujuh {
  position: fixed;
  top: 157px;
  left: 720px;

}
.selamatdatang {
  position: fixed;
  top: 15px;
  right: 130px;
  }
 
.daftarpasien {
  position: fixed;
  margin-top: 20px;
  left: 110px;

}
.exit {
  position: fixed;
  top: 10px;
  right: 10px;

}
.textdaftarpasien {
  position: fixed;
  top: 5px;
  color: white;
}
.home {
  position: fixed;
   margin-top: 5px;
  left: 20px;
  }
  .hometext {
  position: fixed;
  top: 15px;
  color: white;
  }
  .h1title {
  position:fixed;
  top: 70px;
  left: 20px;
  background-color:transparent;
  text-decoration: none;
  background: 0.2s;
  color: green;
  box-sizing: border-box;
  }
   

  body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

.id{
  margin-right: 50px;
}
/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

.modal{
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  right: 30;
  margin-top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top:100px;
}
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
 height:160%;
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 100px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 170%;
  }
}
.btnform {
     margin-left: 30px;
     margin-top: 70px;
  }
  .inputform {
    padding-top:15px;
    font-size:13px;
    width: 300px;
    }
.save{
  background-color: #008CBA;
  margin-top: 5px;
  width: 100px;
  height: 70px;
}
    .batal{
      position: absolute;
  background-color:rgb(179, 78, 71);
  width: 74px;
  margin-left: 5px;
  margin-top: 5px;

 
    }
 
    .search{
      margin-left: 20px;
      margin-right: 900px;
    }
  
  .home {
  position: fixed;
   margin-top: 5px;
  left: 20px;
  }
  .hometext {
  position: fixed;
  top: 15px;
  color: white;
  }
  input[type="date"] {
   width: 100%; 
  padding: 10px;
  font-size: 16px;
}
input[type="time"] {
   width: 100%; 
  padding: 10px;
  font-size: 16px;
}
div.dt-container {
        width: 800px;
        margin: 0 auto;
    }
</style>
<script>
   function closeFunction() {
  }
  </script>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
  }

</script>
</style>
<nav>
    <nav class="navbar navbar-dark bg-success">
   <div class="selamatdatang">
       <p style="color: white;">
        <?php
    if (isset($_SESSION['username'])) {
    echo 'Selamat Datang, ' . htmlspecialchars($_SESSION['username']);
      }
      else{
        
        
      }
       ?>
   </p>
</div>
      <div class="exit">
    <a href="/simrs/index.php?logout=1"><img src="/simrs/asset/images/icon/exit.png" height="30"></a>
      </div>
           <div class="home">
             <div class="hometext">
   <p><a href="../../modul/dasbor/"><img src="/simrs/asset/img/home.png" height="25"></a>  Home</p>
      </div>
        <div class="daftarpasien">
           <div class="textdaftarpasien">
   <p><a href="../../modul/pasien/index.php"><img src="/simrs/asset/images/listpasien.png" height="50"></a>Pasien</p>
      </div>
    </nav>
 
</div>
</nav>
</head>
<body>
  <div>
  <h1 class="h1title"> LABORATORIUM</h1>
</div>

<div class="btnform">
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Buka Form</button>
</div>
<div id="id01" class="modal">
  <form class="modal-content animate" action="../../modul/laboratorium/index.php" method="post">
    <div class="container">
   <div class="inputform">
<label>No. RM</label>
 <input type="text"  name="no_rkm_medis" id="no_rkm_medis"  placeholder="No RM" required>
 <label>Nama Pasien</label>
  <input type="text"  name="nama" id="nama"  placeholder="Nama Pasien" required>
  <table>Tgl Periksa</table>
 <input type="date"  name="tgl_periksa"  required>
   <table>Jam Periksa</table>
  <input type="time"  name="jam_periksa"  required>
  <div class="mt-3">
<label for="nama_dokter" >Dokter</label><br>
        <select id="nama_dokter" name="nama_dokter" required>
            <option value="">Pilih Dokter</option>
            <!-- Dropdown akan diisi dari database menggunakan PHP -->
            <?php
            // Koneksi ke database MySQL
            $conn = new mysqli('localhost', 'root', '', 'simrs');  // Ganti dengan konfigurasi MySQL Anda

            if ($conn->connect_error) {
                die("Koneksi gagal: " . $conn->connect_error);
            }

            // Query untuk mengambil data kategori
            $sql = "SELECT * FROM dokter";
            $result = $conn->query($sql);

            // Menampilkan pilihan kategori
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['nama_dokter'] . "'>" . $row['nama_dokter'] . "</option>";
            }

            // Menutup koneksi
            $conn->close();
            ?>
        </select><br><br>
        <label for="nama_pj">Bayar</label><br>
        <select id="nama_pj" name="nama_pj" required>
            <option value="">Pilih Bayar</option>
            <!-- Dropdown akan diisi dari database menggunakan PHP -->
            <?php
            // Koneksi ke database MySQL
            $conn = new mysqli('localhost', 'root', '', 'simrs');  // Ganti dengan konfigurasi MySQL Anda

            if ($conn->connect_error) {
                die("Koneksi gagal: " . $conn->connect_error);
            }

            // Query untuk mengambil data kategori
            $sql = "SELECT * FROM penjab";
            $result = $conn->query($sql);

            // Menampilkan pilihan kategori
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['kd_pj'] . "'>" . $row['nama_pj'] . "</option>";
            }

            // Menutup koneksi
            $conn->close();
            ?>
            
        </select><br><br>
          <label for="hasil_lab">Hasil Lab</label><br>
       <input type="text"  name="hasil_lab"  required>

   </div>
   <div class="simpan">
<button class="simpan" name="simpan"><img src="../../asset/img/save.png" width="15">Simpan
</button>
   <script>
  // Saat user mengetik No RM, otomatis cari data
  $('#no_rkm_medis').on('input', function () {
    const noRM = $(this).val();

    if (noRM.length >= 3) { // Biar gak query terus-terusan
      $.ajax({
        url: 'get_pasien.php',
        type: 'POST',
        dataType: 'json',
        data: { no_rkm_medis: noRM },
        success: function(response) {
          if (response.nama) {
            $('#nama').val(response.nama);
           
          } else {
     
          }
        },
        error: function() {
          $('#nama').val('');
          console.error('Gagal mengambil data pasien.');
        }
      });
    } else {
      $('#nama').val('');
    }
  });


  $('#form').on('submit', function(e) {
    e.preventDefault();
    alert('Form disubmit. Tambahkan logika simpan di sini.');
   
  });
</script>
   </div>

  <div class="batal">
<button type="button" class="batal" onclick="document.getElementById('id01').style.display='none'">Batal
</button>
  </div>
</body>
</html>
</div>

  </div>                
<?php
// Membuka koneksi ke database
$conn = new mysqli("localhost", "root", "", "simrs");

// Memastikan koneksi berhasil
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query pertama
$result = $conn->query("SELECT * FROM laborat");

// Jika perlu, simpan hasil query, baru setelah itu menutup koneksi
// Menutup koneksi setelah semua query selesai
$conn->close();

$conn = new mysqli("localhost", "root", "", "simrs");
$result2 = $conn->query("SELECT * FROM laborat");
$conn->close();


?>




</div>
<table id="example" class="display nowrap">
    <thead>
            <tr>
                <th>NO.RM</th>
                <th>Nama Pasien</th>
                <th>Tgl Periksa</th>
                <th>Jam Periksa</th>
                 <th>Dokter</th>
                 <th>Bayar</th>
                 <th>Hasil Lab</th>
                 <th>Aksi</th>     
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row["no_rkm_medis"]) ?></td>
                       <td><?= htmlspecialchars($row["nama"]) ?></td>
                        <td><?= htmlspecialchars($row["tgl_periksa"]) ?></td>
                        <td><?= htmlspecialchars($row["jam_periksa"]) ?></td>
                           <td><?= htmlspecialchars($row["nama_dokter"]) ?></td>
                            <td><?= htmlspecialchars($row["nama_pj"]) ?></td>
                             <td><?= htmlspecialchars($row["hasil_lab"]) ?></td>
                             <td><a href="?id=<?= $row['id'] ?>" onclick="return confirm('Yakin mau hapus?')">
                        <img src="../../asset/img/delete.png" width="20">
                      </a></td>   
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center">Data tidak ditemukan.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
 
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap4.js"></script>
<script>
  new DataTable('#example', {
    scrollX: true
});
  </script>
</div>
</form>


</div>
</div>






<tr>
<tr>
 
<footer style="margin-top: 40px;">
<div class="footer">
  <div class="tanggal">
<footer style="text-align: left ; margin-top: 7px;  color: white;">
  <span id="tanggal"></span>

  <script>
    const hari = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    const bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

    const now = new Date();
    const hariIni = hari[now.getDay()];
    const tanggal = now.getDate();
    const bulanIni = bulan[now.getMonth()];
    const tahun = now.getFullYear();

    document.getElementById('tanggal').innerText = `${hariIni}, ${tanggal} ${bulanIni} ${tahun}`;
  </script>
</footer>
</div>
</div>



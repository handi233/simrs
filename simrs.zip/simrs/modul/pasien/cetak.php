
<?php
session_start();

// Cek apakah user sudah login (cek session user_id)
if (!isset($_SESSION['user_id'])) {

}

// Jika sudah login, lanjutkan tampilkan halaman dashboard
?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Pendaftaran Pasien</title>
</head>
<body>
 
	<center>
 <h3>Pendaftaran Pasien</h3>
 
	</center>
 
<?php 
	$conn = mysqli_connect('localhost','root','','simrs');
	?>
 
	<table border="1" style="width: 100%">
		<tr>
		
			<th width="1%">No RM</th>
		  <th>No KTP</th>
                <th>NAMA</th>
			<th width="5%">Alamat</th>
      	    <th>Gender</th>
                     <th>Tempat Lahir</th>
                     <th>Tanggal Lahir</th>
            	
		</tr>
		<?php 
		$sql = mysqli_query($conn,"select * from pasien");
		while($data = mysqli_fetch_array($sql)){
		?>
		<tr>
			<td><?php echo $data['no_rkm_medis']; ?></td>
			<td><?php echo $data['no_ktp']; ?></td>
      <td><?php echo $data['nama']; ?></td>
      <td><?php echo $data['alamat']; ?></td>
      <td><?php echo $data['jk']; ?></td>
      <td><?php echo $data['tmp_lahir']; ?></td>
       <td><?php echo $data['tgl_lahir']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
 
	<script>
		window.print();
	</script>
 

</body>
</html>